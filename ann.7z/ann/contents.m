% Bounded Adaptive Neural Networks Library.
% Version 1.1 (R11.1,R14)  1-Jan-2007
% 
% Giampiero Campa, West Virginia University
% 
% 
%
% LIBRARY:
%
% ann       : open the bounded neural network library.
% 
%
% EXAMPLES :
%
% anndemo   : main demo file.
%
